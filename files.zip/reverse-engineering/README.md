### Setup

Usually for reverse engineering binaries or executables, you want something like a decompiler.

Common decompilers used are [Ghidra](https://github.com/NationalSecurityAgency/ghidra/releases) and [IDA](https://hex-rays.com/ida-free/).

Budget online decompilers (my fav) can be found on dogbolt.org. 

Interestingly enough, online compilers can be found on godbolt.org